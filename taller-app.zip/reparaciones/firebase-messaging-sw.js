importScripts('https://www.gstatic.com/firebasejs/10.12.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.12.0/firebase-messaging-compat.js');

firebase.initializeApp({
  apiKey: "AIzaSyAIputL9dUBWP8vtRe1GurvV3SeeI1KFH4",
  authDomain: "taller-5cc11.firebaseapp.com",
  databaseURL: "https://taller-5cc11-default-rtdb.europe-west1.firebasedatabase.app",
  projectId: "taller-5cc11",
  storageBucket: "taller-5cc11.firebasestorage.app",
  messagingSenderId: "106949189017",
  appId: "1:106949189017:web:ad904041df11bd207a4708"
});

const messaging = firebase.messaging();

// Notificacions quan l'app està en segon pla
messaging.onBackgroundMessage(function(payload) {
  const { title, body } = payload.notification || {};
  self.registration.showNotification(title || 'Serralleria Les Tries', {
    body: body || 'Nova reparació entrada',
    icon: '/icon-192.png',
    badge: '/icon-192.png',
    vibrate: [200, 100, 200],
    data: payload.data || {}
  });
});
